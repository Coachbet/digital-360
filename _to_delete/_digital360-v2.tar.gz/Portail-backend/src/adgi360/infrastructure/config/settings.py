from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Configuration centralisée, chargée depuis les variables d'environnement / .env."""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # Base de données
    database_url: str = "postgresql+asyncpg://adgi360:adgi360@localhost:5433/adgi360"

    # Stockage fichiers (MinIO en local, S3 en production)
    s3_endpoint_url: str = "http://localhost:9000"
    s3_access_key: str = "adgi360"
    s3_secret_key: str = "adgi360secret"
    s3_bucket: str = "adgi360-files"
    s3_region: str = "us-east-1"

    # n8n — workflow d'analyse (un seul webhook, pas d'envoi de mail)
    n8n_webhook_url: str = "http://localhost:5678/webhook/auto-review"
    # Adresse à laquelle n8n rappelle le backend. Vue depuis le conteneur n8n,
    # l'hôte s'appelle host.docker.internal — pas localhost.
    backend_public_url: str = "http://host.docker.internal:8001"

    # --- Sécurité
    # Valeur de développement uniquement : en production, SECRET_KEY doit être
    # fournie par l'environnement, sinon les jetons de toutes les instances
    # seraient interchangeables.
    secret_key: str = "dev-secret-a-remplacer-en-production"
    access_token_ttl_minutes: int = 60 * 12

    # CORS
    frontend_origin: str = "http://localhost:5173"


settings = Settings()
