import { Sparkles } from "lucide-react";
import { useEffect, useState } from "react";

import { Review, autoReviewApi } from "@/features/auto-review/api";
import ReviewCard from "@/features/auto-review/components/ReviewCard";
import ReviewForm from "@/features/auto-review/components/ReviewForm";
import { PageHeader } from "@/shared/components/AppLayout";
import { Card, CardContent } from "@/shared/components/ui/Card";

export default function AutoReviewPage() {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [error, setError] = useState<string | null>(null);

  const refresh = () =>
    autoReviewApi
      .list()
      .then(setReviews)
      .catch((e) => setError(e.message));

  useEffect(() => {
    refresh();
    // n8n travaille en arrière-plan et dépose le rapport dans MinIO :
    // on interroge périodiquement pour voir arriver les rapports à valider.
    const timer = setInterval(refresh, 10000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div>
      <PageHeader
        title="Auto Review"
        description="Lance l’analyse d’un rapport, relis le PowerPoint produit, puis valide-le. Rien n’est envoyé : le fichier se télécharge depuis le portail."
      />

      {error && (
        <div className="mb-6 rounded-xl border border-danger/20 bg-danger/5 px-4 py-3 text-sm text-danger">
          {error}
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-[minmax(0,380px)_1fr]">
        <ReviewForm onLaunched={refresh} onError={setError} />

        <div>
          <h2 className="mb-3 text-sm font-semibold text-muted-foreground">
            Rapports ({reviews.length})
          </h2>

          {reviews.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center gap-2 p-16 text-center">
                <Sparkles className="h-8 w-8 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">
                  Aucune review lancée pour le moment
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {reviews.map((review) => (
                <ReviewCard
                  key={review.id}
                  review={review}
                  onChanged={refresh}
                  onError={setError}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
