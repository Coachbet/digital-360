import { Sparkles } from "lucide-react";
import { useEffect, useState } from "react";

import { ClientType, autoReviewApi } from "@/features/auto-review/api";
import { Client, clientsApi } from "@/features/clients/api";
import { DataFile, dataApi } from "@/features/data/api";
import { Button } from "@/shared/components/ui/Button";
import { Card, CardContent } from "@/shared/components/ui/Card";
import { Label, Select, Textarea } from "@/shared/components/ui/Field";
import { formatBytes } from "@/shared/lib/utils";

/**
 * Formulaire de lancement : on choisit le client, le type de client, les
 * fichiers sources (déposés au préalable dans le module Données) et des infos
 * complémentaires. Le backend transmet le tout à n8n.
 */
export default function ReviewForm({
  onLaunched,
  onError,
}: {
  onLaunched: () => void;
  onError: (message: string) => void;
}) {
  const [clients, setClients] = useState<Client[]>([]);
  const [clientTypes, setClientTypes] = useState<ClientType[]>([]);
  const [files, setFiles] = useState<DataFile[]>([]);

  const [clientId, setClientId] = useState("");
  const [clientType, setClientType] = useState("");
  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    Promise.all([clientsApi.list(), autoReviewApi.clientTypes()])
      .then(([clientList, types]) => {
        setClients(clientList);
        setClientTypes(types);
        if (clientList.length > 0) {
          setClientId(clientList[0].id);
          setClientType(clientList[0].client_type);
        }
      })
      .catch((e) => onError(e.message));
  }, []);

  useEffect(() => {
    if (!clientId) return;
    setSelectedFiles([]);
    dataApi
      .listFiles(clientId)
      .then(setFiles)
      .catch((e) => onError(e.message));
  }, [clientId]);

  const toggleFile = (id: string) =>
    setSelectedFiles((current) =>
      current.includes(id) ? current.filter((f) => f !== id) : [...current, id],
    );

  const submit = async () => {
    setBusy(true);
    try {
      await autoReviewApi.launch({
        client_id: clientId,
        client_type: clientType,
        data_file_ids: selectedFiles,
        additional_info: info || null,
      });
      setSelectedFiles([]);
      setInfo("");
      onLaunched();
    } catch (e) {
      onError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const canSubmit = clientId && clientType && selectedFiles.length > 0 && !busy;

  return (
    <Card className="h-fit">
      <CardContent className="space-y-5 p-6">
        <div>
          <Label htmlFor="review-client">Client</Label>
          <Select
            id="review-client"
            value={clientId}
            onChange={(e) => {
              setClientId(e.target.value);
              const found = clients.find((c) => c.id === e.target.value);
              if (found) setClientType(found.client_type);
            }}
          >
            {clients.length === 0 && <option value="">Aucun client</option>}
            {clients.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </Select>
        </div>

        <div>
          <Label htmlFor="review-type">Type de client</Label>
          <Select
            id="review-type"
            value={clientType}
            onChange={(e) => setClientType(e.target.value)}
          >
            {clientTypes.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </Select>
        </div>

        <div>
          <Label>
            Fichiers sources
            {selectedFiles.length > 0 && (
              <span className="ml-1 font-normal text-primary">
                ({selectedFiles.length} sélectionné{selectedFiles.length > 1 ? "s" : ""})
              </span>
            )}
          </Label>
          <div className="max-h-56 overflow-y-auto rounded-xl border border-border">
            {files.length === 0 ? (
              <p className="p-4 text-center text-xs text-muted-foreground">
                Aucun fichier pour ce client. Dépose-les d'abord dans « Données ».
              </p>
            ) : (
              files.map((file) => (
                <label
                  key={file.id}
                  className="flex cursor-pointer items-center gap-3 border-b border-border px-3 py-2.5 last:border-0 hover:bg-muted/50"
                >
                  <input
                    type="checkbox"
                    checked={selectedFiles.includes(file.id)}
                    onChange={() => toggleFile(file.id)}
                    className="h-4 w-4 accent-[hsl(var(--primary))]"
                  />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm">{file.filename}</span>
                    <span className="block text-xs text-muted-foreground">
                      {file.period} · {formatBytes(file.size_bytes)}
                    </span>
                  </span>
                </label>
              ))
            )}
          </div>
        </div>

        <div>
          <Label htmlFor="review-info">Infos complémentaires</Label>
          <Textarea
            id="review-info"
            value={info}
            onChange={(e) => setInfo(e.target.value)}
            placeholder="Contexte, points à mettre en avant, ton du rapport..."
          />
        </div>

        <Button className="w-full" size="lg" disabled={!canSubmit} onClick={submit}>
          <Sparkles className="h-4 w-4" />
          {busy ? "Lancement..." : "Lancer la review"}
        </Button>
      </CardContent>
    </Card>
  );
}
