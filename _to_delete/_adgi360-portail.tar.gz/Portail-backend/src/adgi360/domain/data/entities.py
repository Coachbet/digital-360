from dataclasses import dataclass
from datetime import datetime


@dataclass
class DataFile:
    """Entité de domaine : un fichier source déposé pour un client et une période."""

    id: str
    client_id: str
    period: str
    filename: str
    storage_key: str
    content_type: str | None = None
    size_bytes: int | None = None
    uploaded_at: datetime | None = None


def build_storage_key(client_id: str, period: str, filename: str) -> str:
    """Construit la clé de stockage S3/MinIO : clients/<client>/<période>/<fichier>.

    C'est cette convention qui matérialise l'organisation « par client, puis par
    période » demandée : elle est lisible directement dans la console MinIO et
    dans les workflows n8n.
    """
    return f"clients/{client_id}/{period}/{filename}"


def build_report_key(review_id: str, filename: str) -> str:
    """Clé de stockage des rapports générés par n8n."""
    return f"reports/{review_id}/{filename}"
