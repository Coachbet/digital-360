import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from adgi360.infrastructure.config.settings import settings
from adgi360.infrastructure.db.session import init_db
from adgi360.infrastructure.storage.client import FileStorage
from adgi360.interfaces.api.v1.routers import auto_review, calendar, clients, data, health

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Au démarrage : crée les tables et s'assure que le bucket existe.

    Les erreurs ne sont pas fatales pour laisser l'API démarrer même si Docker
    n'est pas encore lancé — /api/v1/health répondra et indiquera le problème.
    """
    try:
        await init_db()
    except Exception as exc:
        logger.warning("Base de données indisponible au démarrage : %s", exc)
    try:
        await FileStorage().ensure_bucket()
    except Exception as exc:
        logger.warning("Stockage indisponible au démarrage : %s", exc)
    yield


app = FastAPI(
    title="adgi360 — Portail API",
    version="0.1.0",
    description="API du portail interne adgi360 : données clients, auto-review et calendrier.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_origin],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

for router in (health.router, clients.router, data.router, auto_review.router, calendar.router):
    app.include_router(router, prefix="/api/v1")
