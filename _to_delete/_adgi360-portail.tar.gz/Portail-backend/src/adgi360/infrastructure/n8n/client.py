"""Client d'appel au workflow n8n de reporting automatique.

Contrat convenu : le backend envoie un POST sur le webhook n8n avec les
informations de la review. n8n génère le PowerPoint puis le dépose directement
dans MinIO sous la clé `reports/<review_id>/`. Le backend détecte ensuite ce
dépôt (voir application/auto_review/use_cases/sync_reports.py) et bascule la
review en « à valider ».
"""

import httpx

from adgi360.infrastructure.config.settings import settings
from adgi360.shared.exceptions import ExternalServiceError


class N8nClient:
    def __init__(self, webhook_url: str | None = None, timeout: float = 30.0) -> None:
        self._webhook_url = webhook_url or settings.n8n_webhook_url
        self._timeout = timeout

    async def trigger_auto_review(self, payload: dict) -> None:
        """Déclenche le workflow. Le payload contient tout ce dont n8n a besoin :
        identité du client, type de client, fichiers sources (clés MinIO) et
        l'emplacement où déposer le rapport produit."""
        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                response = await client.post(self._webhook_url, json=payload)
                response.raise_for_status()
        except httpx.HTTPError as exc:
            raise ExternalServiceError(f"Appel n8n en échec : {exc}") from exc


def get_n8n_client() -> N8nClient:
    """Dépendance FastAPI."""
    return N8nClient()
