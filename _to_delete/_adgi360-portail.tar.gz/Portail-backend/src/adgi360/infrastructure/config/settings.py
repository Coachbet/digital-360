from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Configuration centralisée, chargée depuis les variables d'environnement / .env."""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # Base de données
    database_url: str = "postgresql+asyncpg://adgi360:adgi360@localhost:5432/adgi360"

    # Stockage fichiers (MinIO en local, S3 en production)
    s3_endpoint_url: str = "http://localhost:9000"
    s3_access_key: str = "adgi360"
    s3_secret_key: str = "adgi360secret"
    s3_bucket: str = "adgi360-files"
    s3_region: str = "us-east-1"

    # n8n
    n8n_webhook_url: str = "http://localhost:5678/webhook/auto-review"

    # CORS
    frontend_origin: str = "http://localhost:5173"


settings = Settings()
