from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from adgi360.domain.auto_review.entities import ClientType, ReviewStatus
from adgi360.infrastructure.db.models import ClientModel, DataFileModel, ReviewRequestModel
from adgi360.infrastructure.n8n.client import N8nClient
from adgi360.shared.exceptions import ExternalServiceError, NotFoundError, ValidationError


class LaunchAutoReviewUseCase:
    """Crée une demande de review et déclenche le workflow n8n.

    Le backend ne génère pas le PowerPoint : il transmet à n8n le contexte
    (client, type, fichiers sources) et l'emplacement où déposer le résultat.
    n8n écrit le fichier produit dans MinIO sous `reports/<review_id>/`.
    """

    def __init__(self, session: AsyncSession, n8n_client: N8nClient) -> None:
        self._session = session
        self._n8n = n8n_client

    async def execute(
        self,
        client_id: str,
        client_type: str,
        data_file_ids: list[str],
        additional_info: str | None = None,
    ) -> ReviewRequestModel:
        client = await self._session.get(ClientModel, client_id)
        if client is None:
            raise NotFoundError("Client introuvable")

        try:
            resolved_type = ClientType(client_type)
        except ValueError as exc:
            raise ValidationError(f"Type de client inconnu : {client_type}") from exc

        if not data_file_ids:
            raise ValidationError("Au moins un fichier source doit être sélectionné")

        result = await self._session.execute(
            select(DataFileModel).where(DataFileModel.id.in_(data_file_ids))
        )
        files = list(result.scalars().all())
        if len(files) != len(data_file_ids):
            raise ValidationError("Certains fichiers sélectionnés sont introuvables")

        review = ReviewRequestModel(
            client_id=client_id,
            client_type=resolved_type.value,
            data_file_ids=data_file_ids,
            additional_info=additional_info,
            status=ReviewStatus.PENDING.value,
        )
        self._session.add(review)
        await self._session.commit()
        await self._session.refresh(review)

        payload = {
            "review_id": review.id,
            "client": {
                "id": client.id,
                "name": client.name,
                "contact_email": client.contact_email,
            },
            "client_type": resolved_type.value,
            "client_type_label": resolved_type.label,
            "additional_info": additional_info,
            "source_files": [
                {
                    "id": f.id,
                    "filename": f.filename,
                    "storage_key": f.storage_key,
                    "period": f.period,
                    "content_type": f.content_type,
                }
                for f in files
            ],
            # Emplacement où n8n doit déposer le PowerPoint généré
            "output_prefix": f"reports/{review.id}/",
        }

        try:
            await self._n8n.trigger_auto_review(payload)
        except ExternalServiceError as exc:
            review.status = ReviewStatus.FAILED.value
            review.error_message = str(exc)
            await self._session.commit()
            await self._session.refresh(review)
            raise

        review.status = ReviewStatus.PROCESSING.value
        await self._session.commit()
        await self._session.refresh(review)
        return review
