from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from adgi360.application.auto_review.use_cases.approve_review import ApproveReviewUseCase
from adgi360.application.auto_review.use_cases.launch_auto_review import LaunchAutoReviewUseCase
from adgi360.application.auto_review.use_cases.sync_reports import SyncReportsUseCase
from adgi360.domain.auto_review.entities import ClientType, ReviewStatus
from adgi360.infrastructure.db.models import ClientModel, ReviewRequestModel
from adgi360.infrastructure.db.session import get_session
from adgi360.infrastructure.n8n.client import N8nClient, get_n8n_client
from adgi360.infrastructure.storage.client import FileStorage, get_storage
from adgi360.interfaces.api.v1.schemas.auto_review_schemas import (
    AutoReviewCreate,
    AutoReviewDetailOut,
    AutoReviewOut,
    ClientTypeOut,
    ReportDownloadOut,
)
from adgi360.shared.exceptions import ExternalServiceError, NotFoundError, ValidationError

router = APIRouter(prefix="/auto-review", tags=["auto-review"])


@router.get("/client-types", response_model=list[ClientTypeOut])
async def list_client_types() -> list[ClientTypeOut]:
    """Liste fixe alimentant le menu déroulant du formulaire."""
    return [ClientTypeOut(value=t.value, label=t.label) for t in ClientType]


@router.post("", response_model=AutoReviewOut, status_code=status.HTTP_202_ACCEPTED)
async def launch_auto_review(
    payload: AutoReviewCreate,
    session: AsyncSession = Depends(get_session),
    n8n: N8nClient = Depends(get_n8n_client),
) -> ReviewRequestModel:
    use_case = LaunchAutoReviewUseCase(session, n8n)
    try:
        return await use_case.execute(
            client_id=payload.client_id,
            client_type=payload.client_type,
            data_file_ids=payload.data_file_ids,
            additional_info=payload.additional_info,
        )
    except NotFoundError as exc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, str(exc)) from exc
    except ValidationError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc)) from exc
    except ExternalServiceError as exc:
        raise HTTPException(status.HTTP_502_BAD_GATEWAY, str(exc)) from exc


@router.get("", response_model=list[AutoReviewDetailOut])
async def list_reviews(
    review_status: str | None = Query(None, alias="status"),
    session: AsyncSession = Depends(get_session),
    storage: FileStorage = Depends(get_storage),
) -> list[AutoReviewDetailOut]:
    """Liste les reviews. Avant de répondre, on vérifie si n8n a déposé de
    nouveaux rapports dans MinIO pour mettre les statuts à jour."""
    try:
        await SyncReportsUseCase(session, storage).execute()
    except ExternalServiceError:
        # Le stockage est indisponible : on renvoie quand même la liste connue.
        pass

    query = select(ReviewRequestModel, ClientModel).join(
        ClientModel, ReviewRequestModel.client_id == ClientModel.id
    )
    if review_status:
        query = query.where(ReviewRequestModel.status == review_status)
    result = await session.execute(query.order_by(ReviewRequestModel.created_at.desc()))

    items: list[AutoReviewDetailOut] = []
    for review, client in result.all():
        items.append(
            AutoReviewDetailOut(
                **{c.name: getattr(review, c.name) for c in review.__table__.columns},
                client_name=client.name,
                status_label=ReviewStatus(review.status).label,
            )
        )
    return items


@router.post("/{review_id}/approve", response_model=AutoReviewOut)
async def approve_review(
    review_id: str, session: AsyncSession = Depends(get_session)
) -> ReviewRequestModel:
    try:
        return await ApproveReviewUseCase(session).execute(review_id)
    except NotFoundError as exc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, str(exc)) from exc
    except ValidationError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc)) from exc


@router.get("/{review_id}/report", response_model=ReportDownloadOut)
async def download_report(
    review_id: str,
    session: AsyncSession = Depends(get_session),
    storage: FileStorage = Depends(get_storage),
) -> ReportDownloadOut:
    """URL temporaire pour télécharger le PowerPoint généré."""
    review = await session.get(ReviewRequestModel, review_id)
    if review is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Review introuvable")
    if not review.report_storage_key:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Aucun rapport disponible")

    url = await storage.presigned_url(review.report_storage_key)
    return ReportDownloadOut(
        url=url,
        filename=review.report_filename or "rapport.pptx",
        expires_in=3600,
    )
