from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from adgi360.domain.data.entities import build_storage_key
from adgi360.infrastructure.db.models import ClientModel, DataFileModel
from adgi360.infrastructure.db.session import get_session
from adgi360.infrastructure.storage.client import FileStorage, get_storage
from adgi360.interfaces.api.v1.schemas.data_schemas import (
    DataFileOut,
    DownloadUrlOut,
    PeriodOut,
)

router = APIRouter(prefix="/data", tags=["data"])


@router.get("/clients/{client_id}/periods", response_model=list[PeriodOut])
async def list_periods(
    client_id: str, session: AsyncSession = Depends(get_session)
) -> list[PeriodOut]:
    """Périodes disponibles pour un client, avec le nombre de fichiers."""
    result = await session.execute(
        select(DataFileModel.period, func.count(DataFileModel.id))
        .where(DataFileModel.client_id == client_id)
        .group_by(DataFileModel.period)
        .order_by(DataFileModel.period.desc())
    )
    return [PeriodOut(period=row[0], file_count=row[1]) for row in result.all()]


@router.get("/files", response_model=list[DataFileOut])
async def list_files(
    client_id: str = Query(...),
    period: str | None = Query(None),
    session: AsyncSession = Depends(get_session),
) -> list[DataFileModel]:
    """Fichiers d'un client, éventuellement filtrés sur une période."""
    query = select(DataFileModel).where(DataFileModel.client_id == client_id)
    if period:
        query = query.where(DataFileModel.period == period)
    result = await session.execute(query.order_by(DataFileModel.uploaded_at.desc()))
    return list(result.scalars().all())


@router.post(
    "/files", response_model=list[DataFileOut], status_code=status.HTTP_201_CREATED
)
async def upload_files(
    client_id: str = Query(...),
    period: str = Query(..., description="Période, ex: 2026-08"),
    files: list[UploadFile] = File(...),
    session: AsyncSession = Depends(get_session),
    storage: FileStorage = Depends(get_storage),
) -> list[DataFileModel]:
    """Dépose un ou plusieurs fichiers pour un client et une période.

    Les fichiers vont dans MinIO sous `clients/<client_id>/<période>/<nom>` ;
    leurs métadonnées sont enregistrées en base pour pouvoir les sélectionner
    ensuite dans le formulaire d'auto-review.
    """
    client = await session.get(ClientModel, client_id)
    if client is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Client introuvable")

    await storage.ensure_bucket()

    created: list[DataFileModel] = []
    for upload in files:
        content = await upload.read()
        key = build_storage_key(client_id, period, upload.filename or "sans-nom")
        await storage.upload(key, content, upload.content_type)

        record = DataFileModel(
            client_id=client_id,
            period=period,
            filename=upload.filename or "sans-nom",
            storage_key=key,
            content_type=upload.content_type,
            size_bytes=len(content),
        )
        session.add(record)
        created.append(record)

    await session.commit()
    for record in created:
        await session.refresh(record)
    return created


@router.get("/files/{file_id}/download", response_model=DownloadUrlOut)
async def get_download_url(
    file_id: str,
    session: AsyncSession = Depends(get_session),
    storage: FileStorage = Depends(get_storage),
) -> DownloadUrlOut:
    record = await session.get(DataFileModel, file_id)
    if record is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Fichier introuvable")
    url = await storage.presigned_url(record.storage_key)
    return DownloadUrlOut(url=url, expires_in=3600)


@router.delete("/files/{file_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_file(
    file_id: str,
    session: AsyncSession = Depends(get_session),
    storage: FileStorage = Depends(get_storage),
) -> None:
    record = await session.get(DataFileModel, file_id)
    if record is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Fichier introuvable")
    await storage.delete(record.storage_key)
    await session.delete(record)
    await session.commit()
