from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from adgi360.infrastructure.db.models import ClientModel
from adgi360.infrastructure.db.session import get_session
from adgi360.interfaces.api.v1.schemas.client_schemas import ClientCreate, ClientOut

router = APIRouter(prefix="/clients", tags=["clients"])


@router.get("", response_model=list[ClientOut])
async def list_clients(session: AsyncSession = Depends(get_session)) -> list[ClientModel]:
    result = await session.execute(select(ClientModel).order_by(ClientModel.name))
    return list(result.scalars().all())


@router.post("", response_model=ClientOut, status_code=status.HTTP_201_CREATED)
async def create_client(
    payload: ClientCreate, session: AsyncSession = Depends(get_session)
) -> ClientModel:
    existing = await session.execute(select(ClientModel).where(ClientModel.name == payload.name))
    if existing.scalar_one_or_none() is not None:
        raise HTTPException(status.HTTP_409_CONFLICT, "Un client porte déjà ce nom")

    client = ClientModel(
        name=payload.name,
        client_type=payload.client_type,
        contact_email=payload.contact_email,
    )
    session.add(client)
    await session.commit()
    await session.refresh(client)
    return client


@router.get("/{client_id}", response_model=ClientOut)
async def get_client(client_id: str, session: AsyncSession = Depends(get_session)) -> ClientModel:
    client = await session.get(ClientModel, client_id)
    if client is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Client introuvable")
    return client


@router.delete("/{client_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_client(client_id: str, session: AsyncSession = Depends(get_session)) -> None:
    client = await session.get(ClientModel, client_id)
    if client is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Client introuvable")
    await session.delete(client)
    await session.commit()
