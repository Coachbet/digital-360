# adgi360 — Contexte projet

## Quoi
Portail web interne pour **adgi360**, agence de marketing digital. Deux applications séparées qui communiquent via une API :

- **Frontend** : `Portail-front end/` — React + TypeScript + Vite + Tailwind (voir son `CLAUDE.md`)
- **Backend** : `Portail-backend/` — FastAPI en DDD (voir son `CLAUDE.md`)

Ce fichier est le contexte général à lire en premier.

## Emplacement
Le projet vit dans `~/Documents/adgi360` (déplacé hors de OneDrive : la synchro de `node_modules` et `.venv` provoquait des blocages).

## Stack

| Couche | Techno | Notes |
|---|---|---|
| Frontend | React 18 + TypeScript + Vite + Tailwind CSS | Organisation par *features*, composants UI maison façon shadcn |
| Backend | Python 3.11+ + FastAPI | Architecture DDD : `domain` / `application` / `infrastructure` / `interfaces` |
| Base de données | PostgreSQL 16 (Docker) | SQLAlchemy 2 async + asyncpg |
| Stockage fichiers | MinIO (Docker), API compatible S3 | Bucket `adgi360-files`, migration vers un vrai S3 sans changer le code |
| Automatisation | n8n, instance locale déjà en place | Déclenché par le backend via webhook |
| Dépôts | 2 repos Git séparés (FE et BE), privés, sur le compte GitHub personnel | Pas encore fait |

## Démarrer le projet

```bash
# 1. Infra (à la racine du projet)
docker compose up -d

# 2. Backend
cd Portail-backend
source ~/.venvs/adgi360-backend/bin/activate
pip install -e ".[dev]"
cp .env.example .env
uvicorn adgi360.main:app --reload --app-dir src --port 8000

# 3. Frontend (autre terminal)
cd "Portail-front end"
npm install
npm run dev
```

- Portail : http://localhost:5173
- API + doc interactive : http://localhost:8000/docs
- Console MinIO : http://localhost:9001 (adgi360 / adgi360secret)
- État des dépendances : http://localhost:8000/api/v1/health

Le venv Python est volontairement hors du projet (`~/.venvs/adgi360-backend`).

## Modules du portail

### 1. Données (`/data`)
Gestion des fichiers sources, **organisés par client puis par période** (`clients/<client_id>/<période>/<fichier>` dans MinIO). C'est le préalable à l'auto-review : on dépose ici, on sélectionne ensuite.

### 2. Auto Review (`/auto-review`)
Le flux complet :

1. L'utilisateur choisit un client, un **type de client** (liste fixe : e-commerce, B2B, lead gen, marketplace, local, marque, autre), coche les **fichiers sources** déjà déposés dans le module Données, et ajoute des infos complémentaires.
2. Le backend crée une `ReviewRequest` et appelle le **webhook n8n** avec : identité du client, type, clés MinIO des fichiers, et le préfixe `reports/<review_id>/` où déposer le résultat.
3. **n8n génère le PowerPoint** (le backend ne le fait pas) et le dépose directement dans MinIO sous ce préfixe.
4. Le backend détecte le dépôt (`SyncReportsUseCase`, appelé à chaque listing) et bascule la review en « à valider ».
5. Un **humain valide** dans le portail. **Aucun envoi automatique** : après validation, le rapport est simplement téléchargeable, et c'est un humain qui décide de la suite.

Statuts : `pending` → `processing` → `awaiting_approval` → `approved` (ou `failed`).

### 3. Calendrier (`/calendrier`)
Quatre usages : échéances de rapports, planning de campagnes, rendez-vous clients, planning interne. Synchro **Google Calendar en lecture seule** (Google Workspace est l'outil de l'équipe ; Outlook n'est pas concerné). Le client Google est en place mais l'authentification reste à configurer — le calendrier interne fonctionne sans.

### 4. Reporting
Prévu, pas encore développé (carte grisée sur l'accueil).

## Design
Charte inspirée du site adigi360.com : **accent magenta/rose sur fond clair**, typo Inter. Les tokens de couleur sont dans `Portail-front end/src/app/global.css` (variables CSS en HSL) et exposés à Tailwind via `tailwind.config.js`. Page d'accueil : un gros bloc arrondi par application.

## Authentification
**Aucune pour l'instant** (2-3 utilisateurs internes, tout en local). La structure est prête à en accueillir une : côté front tous les appels passent par `src/shared/api/client.ts`, côté back il suffira d'ajouter une dépendance FastAPI.

## Décisions prises
- FastAPI plutôt que Django/Flask : léger, async, adapté au DDD.
- Vite plutôt que Create React App.
- n8n génère le PPT, pas le backend.
- Pas d'envoi automatique de mail : validation humaine puis téléchargement manuel.
- Synchro Google en lecture seule pour éviter tout risque sur les agendas de l'équipe.
- Projet sorti de OneDrive.

## Reste à faire
- [ ] Configurer l'authentification Google Calendar (compte de service ou OAuth2)
- [ ] Créer le workflow n8n `auto-review` correspondant au contrat d'appel
- [ ] Migrations Alembic (aujourd'hui : `create_all` au démarrage, suffisant en dev)
- [ ] Module Reporting
- [ ] Authentification du portail
- [ ] Init Git + 2 repos privés sur GitHub
- [ ] Choix d'hébergement

## Contrat d'appel backend → n8n

Le backend envoie un POST sur `N8N_WEBHOOK_URL` avec :

```json
{
  "review_id": "uuid",
  "client": { "id": "uuid", "name": "Acme", "contact_email": "..." },
  "client_type": "ecommerce",
  "client_type_label": "E-commerce",
  "additional_info": "texte libre",
  "source_files": [
    { "id": "uuid", "filename": "export.xlsx", "storage_key": "clients/<id>/2026-08/export.xlsx", "period": "2026-08", "content_type": "..." }
  ],
  "output_prefix": "reports/<review_id>/"
}
```

Le workflow n8n doit lire les fichiers depuis MinIO via `storage_key`, produire le PowerPoint, et l'écrire dans le bucket `adgi360-files` sous `output_prefix`. Rien d'autre n'est attendu : le backend détecte le fichier tout seul.
