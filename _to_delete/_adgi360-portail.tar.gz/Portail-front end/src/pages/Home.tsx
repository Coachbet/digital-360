import { BarChart3, CalendarDays, FolderOpen, Sparkles } from "lucide-react";
import { useEffect, useState } from "react";

import AppCard from "@/shared/components/AppCard";
import { api } from "@/shared/api/client";

interface Review {
  id: string;
  status: string;
}

/**
 * Page d'accueil : un gros bloc par application.
 * Ajouter une carte ici à chaque nouveau module métier.
 */
export default function HomePage() {
  const [toApprove, setToApprove] = useState<number | null>(null);

  useEffect(() => {
    api
      .get<Review[]>("/auto-review?status=awaiting_approval")
      .then((reviews) => setToApprove(reviews.length))
      .catch(() => setToApprove(null));
  }, []);

  return (
    <div>
      <div className="mb-10">
        <h1 className="text-3xl font-bold tracking-tight">Bonjour 👋</h1>
        <p className="mt-2 text-muted-foreground">
          Choisis une application pour commencer.
        </p>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <AppCard
          title="Données"
          description="Dépose et organise les fichiers sources de chaque client, par période."
          to="/data"
          icon={FolderOpen}
          accent="bg-primary-soft text-primary"
        />
        <AppCard
          title="Auto Review"
          description="Lance la génération d'un rapport et valide-le avant diffusion."
          to="/auto-review"
          icon={Sparkles}
          accent="bg-primary text-primary-foreground"
          badge={toApprove ? `${toApprove} à valider` : undefined}
        />
        <AppCard
          title="Calendrier"
          description="Échéances de rapports, campagnes, rendez-vous clients et planning interne."
          to="/calendrier"
          icon={CalendarDays}
          accent="bg-foreground text-background"
        />
        <AppCard
          title="Reporting"
          description="Tableaux de bord de performance consolidés par client."
          to="/reporting"
          icon={BarChart3}
          accent="bg-muted text-muted-foreground"
          disabled
          badge="Bientôt"
        />
      </div>
    </div>
  );
}
