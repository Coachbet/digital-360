import { CalendarDays, FolderOpen, LayoutGrid, Sparkles } from "lucide-react";
import { ReactNode } from "react";
import { NavLink, Link } from "react-router-dom";

import { cn } from "@/shared/lib/utils";

const NAV = [
  { to: "/", label: "Accueil", icon: LayoutGrid, end: true },
  { to: "/data", label: "Données", icon: FolderOpen },
  { to: "/auto-review", label: "Auto Review", icon: Sparkles },
  { to: "/calendrier", label: "Calendrier", icon: CalendarDays },
];

export default function AppLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen">
      <aside className="hidden w-60 shrink-0 flex-col border-r border-border bg-card md:flex">
        <Link to="/" className="flex items-center gap-2 px-6 py-6">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-sm font-bold text-primary-foreground">
            a
          </span>
          <span className="text-lg font-bold tracking-tight">
            adgi<span className="text-primary">360</span>
          </span>
        </Link>

        <nav className="flex flex-1 flex-col gap-1 px-3">
          {NAV.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                cn(
                  "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors",
                  isActive
                    ? "bg-primary-soft text-primary"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground",
                )
              }
            >
              <Icon className="h-4 w-4" />
              {label}
            </NavLink>
          ))}
        </nav>

        <p className="px-6 py-4 text-xs text-muted-foreground">Portail interne · v0.1</p>
      </aside>

      <main className="flex-1 overflow-x-hidden">
        <div className="mx-auto max-w-6xl px-6 py-10 md:px-10">{children}</div>
      </main>
    </div>
  );
}

/** En-tête de page réutilisable. */
export function PageHeader({
  title,
  description,
  action,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-8 flex flex-wrap items-start justify-between gap-4">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
        {description && <p className="mt-1 text-sm text-muted-foreground">{description}</p>}
      </div>
      {action}
    </div>
  );
}
