import { ArrowUpRight, LucideIcon } from "lucide-react";
import { Link } from "react-router-dom";

import { Badge } from "@/shared/components/ui/Badge";
import { cn } from "@/shared/lib/utils";

export interface AppCardProps {
  title: string;
  description: string;
  to: string;
  icon: LucideIcon;
  /** Classes Tailwind pour la pastille d'icône, ex: "bg-primary text-white". */
  accent?: string;
  disabled?: boolean;
  badge?: string;
  stat?: string;
}

/**
 * Gros bloc « application » à bords arrondis, utilisé sur la page d'accueil
 * pour entrer dans chaque module du portail.
 */
export default function AppCard({
  title,
  description,
  to,
  icon: Icon,
  accent = "bg-primary text-primary-foreground",
  disabled = false,
  badge,
  stat,
}: AppCardProps) {
  const content = (
    <div
      className={cn(
        "group relative flex h-full min-h-[220px] flex-col justify-between overflow-hidden rounded-3xl border border-border bg-card p-7 shadow-card transition-all",
        disabled
          ? "cursor-not-allowed opacity-60"
          : "hover:-translate-y-1 hover:shadow-card-hover hover:border-primary/30",
      )}
    >
      <div
        className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-primary/5 opacity-0 transition-opacity group-hover:opacity-100"
        aria-hidden
      />

      <div className="flex items-start justify-between">
        <div className={cn("flex h-12 w-12 items-center justify-center rounded-2xl", accent)}>
          <Icon className="h-5 w-5" />
        </div>
        <div className="flex items-center gap-2">
          {badge && <Badge tone="primary">{badge}</Badge>}
          {!disabled && (
            <ArrowUpRight className="h-5 w-5 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-primary" />
          )}
        </div>
      </div>

      <div className="relative">
        {stat && <p className="mb-1 text-2xl font-bold tracking-tight">{stat}</p>}
        <h2 className="text-lg font-semibold tracking-tight">{title}</h2>
        <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{description}</p>
      </div>
    </div>
  );

  if (disabled) return content;
  return (
    <Link to={to} className="block h-full">
      {content}
    </Link>
  );
}
