/**
 * Point d'entrée unique pour tous les appels à l'API backend.
 *
 * Centraliser ici permettra d'ajouter l'authentification plus tard (en-tête
 * Authorization, refresh de token, redirection vers le login) sans toucher aux
 * modules métier.
 */

const BASE_URL = "/api/v1";

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message);
  }
}

async function handle<T>(response: Response): Promise<T> {
  if (!response.ok) {
    let detail = response.statusText;
    try {
      const body = await response.json();
      detail = body.detail ?? detail;
    } catch {
      /* réponse sans corps JSON */
    }
    throw new ApiError(detail, response.status);
  }
  if (response.status === 204) return undefined as T;
  return response.json();
}

export const api = {
  get<T>(path: string): Promise<T> {
    return fetch(`${BASE_URL}${path}`).then(handle<T>);
  },

  post<T>(path: string, body?: unknown): Promise<T> {
    return fetch(`${BASE_URL}${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
    }).then(handle<T>);
  },

  postForm<T>(path: string, formData: FormData): Promise<T> {
    return fetch(`${BASE_URL}${path}`, { method: "POST", body: formData }).then(handle<T>);
  },

  delete<T>(path: string): Promise<T> {
    return fetch(`${BASE_URL}${path}`, { method: "DELETE" }).then(handle<T>);
  },
};
