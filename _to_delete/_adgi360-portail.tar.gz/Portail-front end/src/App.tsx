import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";

import AutoReviewPage from "@/features/auto-review/components/AutoReviewPage";
import CalendarPage from "@/features/calendar/components/CalendarPage";
import DataPage from "@/features/data/components/DataPage";
import HomePage from "@/pages/Home";
import AppLayout from "@/shared/components/AppLayout";

export default function App() {
  return (
    <BrowserRouter>
      <AppLayout>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/data" element={<DataPage />} />
          <Route path="/auto-review" element={<AutoReviewPage />} />
          <Route path="/calendrier" element={<CalendarPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AppLayout>
    </BrowserRouter>
  );
}
