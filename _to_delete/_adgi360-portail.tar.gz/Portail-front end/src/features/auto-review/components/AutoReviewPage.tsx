import { CheckCircle2, Download, FileText, Loader2, Sparkles } from "lucide-react";
import { useEffect, useState } from "react";

import { Review, autoReviewApi } from "@/features/auto-review/api";
import ReviewForm from "@/features/auto-review/components/ReviewForm";
import { PageHeader } from "@/shared/components/AppLayout";
import { Badge, BadgeTone } from "@/shared/components/ui/Badge";
import { Button } from "@/shared/components/ui/Button";
import { Card, CardContent } from "@/shared/components/ui/Card";

const STATUS_TONE: Record<string, BadgeTone> = {
  pending: "neutral",
  processing: "warning",
  awaiting_approval: "primary",
  approved: "success",
  failed: "danger",
};

export default function AutoReviewPage() {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  const refresh = () =>
    autoReviewApi
      .list()
      .then(setReviews)
      .catch((e) => setError(e.message));

  useEffect(() => {
    refresh();
    // n8n travaille en arrière-plan et dépose le rapport dans MinIO :
    // on interroge périodiquement pour voir arriver les rapports à valider.
    const timer = setInterval(refresh, 10000);
    return () => clearInterval(timer);
  }, []);

  const handleApprove = async (review: Review) => {
    setBusyId(review.id);
    try {
      await autoReviewApi.approve(review.id);
      await refresh();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusyId(null);
    }
  };

  const handleDownload = async (review: Review) => {
    const { url } = await autoReviewApi.reportUrl(review.id);
    window.open(url, "_blank");
  };

  return (
    <div>
      <PageHeader
        title="Auto Review"
        description="Lance la génération d'un rapport à partir des fichiers déposés. Le résultat revient ici pour validation avant diffusion."
      />

      {error && (
        <div className="mb-6 rounded-xl border border-danger/20 bg-danger/5 px-4 py-3 text-sm text-danger">
          {error}
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-[minmax(0,380px)_1fr]">
        <ReviewForm onLaunched={refresh} onError={setError} />

        <div>
          <h2 className="mb-3 text-sm font-semibold text-muted-foreground">
            Rapports ({reviews.length})
          </h2>

          {reviews.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center gap-2 p-16 text-center">
                <Sparkles className="h-8 w-8 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">
                  Aucune review lancée pour le moment
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {reviews.map((review) => (
                <Card key={review.id}>
                  <CardContent className="flex flex-wrap items-center gap-4 p-5">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{review.client_name}</p>
                        <Badge tone={STATUS_TONE[review.status] ?? "neutral"}>
                          {review.status_label}
                        </Badge>
                      </div>
                      <p className="mt-1 text-xs text-muted-foreground">
                        {review.data_file_ids.length} fichier
                        {review.data_file_ids.length > 1 ? "s" : ""} ·{" "}
                        {new Date(review.created_at).toLocaleString("fr-FR")}
                      </p>
                      {review.error_message && (
                        <p className="mt-1 text-xs text-danger">{review.error_message}</p>
                      )}
                      {review.report_filename && (
                        <p className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground">
                          <FileText className="h-3 w-3" />
                          {review.report_filename}
                        </p>
                      )}
                    </div>

                    <div className="flex gap-2">
                      {review.status === "processing" && (
                        <span className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          n8n travaille
                        </span>
                      )}
                      {review.status === "awaiting_approval" && (
                        <>
                          <Button
                            variant="secondary"
                            size="sm"
                            onClick={() => handleDownload(review)}
                          >
                            <Download className="h-3.5 w-3.5" />
                            Aperçu
                          </Button>
                          <Button
                            size="sm"
                            disabled={busyId === review.id}
                            onClick={() => handleApprove(review)}
                          >
                            <CheckCircle2 className="h-3.5 w-3.5" />
                            Valider
                          </Button>
                        </>
                      )}
                      {review.status === "approved" && (
                        <Button size="sm" onClick={() => handleDownload(review)}>
                          <Download className="h-3.5 w-3.5" />
                          Télécharger
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
