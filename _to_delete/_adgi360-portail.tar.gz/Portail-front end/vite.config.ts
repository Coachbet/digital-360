import react from "@vitejs/plugin-react";
import path from "path";
import { defineConfig } from "vite";

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: { "@": path.resolve(__dirname, "./src") },
  },
  server: {
    port: 5173,
    proxy: {
      // Les appels /api/* du front sont relayés vers le backend FastAPI local.
      "/api": { target: "http://localhost:8000", changeOrigin: true },
    },
  },
});
