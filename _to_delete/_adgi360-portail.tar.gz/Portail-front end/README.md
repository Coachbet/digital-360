# adgi360 — Portail (Frontend)

React + TypeScript + Vite + Tailwind. Voir `CLAUDE.md` pour le contexte complet.

## Démarrer

```bash
npm install
npm run dev
```

http://localhost:5173 — les appels `/api/*` sont relayés vers le backend sur le port 8000, qui doit tourner en parallèle.

## Écrans

- **Accueil** — un gros bloc arrondi par application
- **Données** — dépôt et organisation des fichiers par client/période
- **Auto Review** — formulaire de lancement et validation des rapports générés
- **Calendrier** — vue mensuelle, création d'événements
